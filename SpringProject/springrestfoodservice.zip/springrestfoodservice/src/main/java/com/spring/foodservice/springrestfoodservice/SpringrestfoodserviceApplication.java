package com.spring.foodservice.springrestfoodservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringrestfoodserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringrestfoodserviceApplication.class, args);
	}

}
