package com.springrest.springrestdata;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringrestdataApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringrestdataApplication.class, args);
	}

}
